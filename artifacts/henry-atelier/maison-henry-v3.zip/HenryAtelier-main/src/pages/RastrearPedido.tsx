import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Search, Package, Truck, CheckCircle2 } from "lucide-react";
import { trackOrder } from "@/lib/supabase";
import { ORDER_STATUS_LABELS } from "@/constants";
import { toast } from "sonner";

interface TrackedOrder {
  order_number: string;
  status: string;
  payment_status: string;
  total: number;
  tracking_code: string | null;
  items: Array<{ product: { name: string }; quantity: number }>;
  created_at: string;
}

export default function RastrearPedido() {
  const [orderNumber, setOrderNumber] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TrackedOrder | null>(null);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderNumber.trim() || !email.trim()) {
      toast.error("Preencha o número do pedido e o e-mail usado na compra.");
      return;
    }
    setLoading(true);
    setSearched(false);
    try {
      const data = await trackOrder(orderNumber, email);
      setResult(data);
      setSearched(true);
      if (!data) toast.error("Não encontramos nenhum pedido com esses dados.");
    } catch (err) {
      toast.error("Erro ao buscar pedido. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-beige-light">
      <header className="bg-white border-b border-stone-200 px-6 py-5">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <Link to="/" className="font-playfair text-lg brand-gold">Maison Henry</Link>
          <Link to="/" className="flex items-center gap-1.5 text-xs text-stone-500 hover:text-gold transition-colors tracking-widest uppercase">
            <ArrowLeft size={14} /> Voltar à loja
          </Link>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-6 py-14">
        <div className="text-center mb-10">
          <Package className="mx-auto text-gold mb-3" size={32} />
          <h1 className="font-playfair text-3xl text-stone-900 mb-2">Rastrear Pedido</h1>
          <p className="text-stone-500 text-sm">Digite o número do pedido e o e-mail usado na compra.</p>
        </div>

        <form onSubmit={handleSearch} className="bg-white border border-stone-200 p-6 space-y-4">
          <div>
            <label className="block text-sm text-stone-600 mb-1.5">Número do pedido</label>
            <input
              value={orderNumber}
              onChange={(e) => setOrderNumber(e.target.value)}
              placeholder="Ex: HA-260909-a1b2c3"
              className="w-full border border-stone-300 px-4 py-3 text-sm focus:outline-none focus:border-gold"
            />
          </div>
          <div>
            <label className="block text-sm text-stone-600 mb-1.5">E-mail</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              className="w-full border border-stone-300 px-4 py-3 text-sm focus:outline-none focus:border-gold"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-stone-900 text-white py-4 font-semibold tracking-widest uppercase text-sm hover:bg-gold transition-colors disabled:opacity-60"
          >
            <Search size={16} /> {loading ? "Buscando..." : "Buscar Pedido"}
          </button>
        </form>

        {searched && result && (
          <div className="bg-white border border-stone-200 p-6 mt-6">
            <div className="flex items-center justify-between mb-4">
              <p className="font-playfair text-lg text-stone-900">Pedido {result.order_number}</p>
              <span className="text-xs font-semibold tracking-widest uppercase text-gold-dark bg-beige px-3 py-1">
                {ORDER_STATUS_LABELS[result.status] ?? result.status}
              </span>
            </div>
            <div className="space-y-2 text-sm text-stone-600 mb-4">
              {result.items?.map((item, i) => (
                <div key={i} className="flex justify-between">
                  <span>{item.quantity}x {item.product?.name}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-stone-100 pt-4 flex items-center justify-between">
              <span className="text-sm text-stone-500">Total</span>
              <span className="font-semibold text-stone-900">
                {result.total?.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
              </span>
            </div>
            {result.tracking_code && (
              <div className="flex items-center gap-2 mt-4 text-sm text-stone-600">
                <Truck size={16} className="text-gold-dark" />
                Código de rastreio: <strong>{result.tracking_code}</strong>
              </div>
            )}
            {result.status === "delivered" && (
              <div className="flex items-center gap-2 mt-4 text-sm text-green-700">
                <CheckCircle2 size={16} /> Pedido entregue!
              </div>
            )}
          </div>
        )}

        {searched && !result && (
          <div className="bg-white border border-stone-200 p-6 mt-6 text-center text-sm text-stone-500">
            Nenhum pedido encontrado com esses dados. Confira o número do pedido e o e-mail, ou fale com a
            gente pelo WhatsApp.
          </div>
        )}
      </main>
    </div>
  );
}
