import React from "react";
import LegalPageLayout from "@/components/layout/LegalPageLayout";

export default function TermosDeUso() {
  return (
    <LegalPageLayout title="Termos de Uso" updatedAt="[preencher data de publicação]">
      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">1. Identificação</h2>
        <p>
          O site Maison Henry ("Site", "nós") é operado por <strong>[Nome completo do responsável]</strong>,
          inscrito(a) no CPF sob o nº <strong>[000.000.000-00]</strong>, com endereço em{" "}
          <strong>[endereço completo para correspondência]</strong>, contato{" "}
          <strong>[e-mail de contato]</strong> e <strong>[telefone/WhatsApp]</strong>.
        </p>
        <p className="mt-3 text-xs text-stone-400 bg-white border border-stone-200 p-3">
          Nota para o lojista: como você vende como pessoa física (sem CNPJ), a identificação acima é
          obrigatória por lei (Marco Civil da Internet, art. 7º, e Código de Defesa do Consumidor) — o
          cliente precisa saber com quem está negociando. Considere formalizar um MEI (Microempreendedor
          Individual): é gratuito para abrir, custa poucos reais por mês e facilita emitir nota fiscal e
          receber pelo Mercado Pago como pessoa jurídica.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">2. Aceitação dos termos</h2>
        <p>
          Ao acessar ou realizar uma compra no Site, você concorda integralmente com estes Termos de Uso e
          com a nossa <a href="/politica-de-privacidade" className="text-gold-dark underline">Política de Privacidade</a> e{" "}
          <a href="/trocas-e-devolucoes" className="text-gold-dark underline">Política de Trocas e Devoluções</a>.
          Caso não concorde, pedimos que não utilize o Site.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">3. Produtos e preços</h2>
        <p>
          Todos os produtos exibidos estão sujeitos à disponibilidade de estoque. Os preços podem ser
          alterados sem aviso prévio, mas o valor válido é sempre aquele informado no momento da confirmação
          do pedido. Fazemos o possível para manter fotos e descrições fiéis, mas pequenas variações de cor
          e aroma entre lotes artesanais podem ocorrer.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">4. Pagamento</h2>
        <p>
          Os pagamentos são processados via Mercado Pago (cartão, Pix e boleto, conforme disponibilidade) ou,
          alternativamente, combinados diretamente via WhatsApp. O pedido só é confirmado após a aprovação
          do pagamento.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">5. Entrega</h2>
        <p>
          Os prazos de entrega informados no checkout são estimativas e podem variar conforme a
          transportadora e a região de destino. O frete é grátis para pedidos acima do valor informado no
          carrinho; abaixo disso, uma taxa fixa é cobrada.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">6. Propriedade intelectual</h2>
        <p>
          Marca, logotipo, textos, fotos e demais conteúdos do Site pertencem a Maison Henry e não podem ser
          reproduzidos sem autorização prévia.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">7. Foro</h2>
        <p>
          Fica eleito o foro da comarca de <strong>[cidade/UF]</strong> para dirimir eventuais controvérsias,
          com renúncia a qualquer outro, por mais privilegiado que seja, ressalvado o direito do consumidor de
          optar pelo foro de seu domicílio, conforme o Código de Defesa do Consumidor.
        </p>
      </section>
    </LegalPageLayout>
  );
}
