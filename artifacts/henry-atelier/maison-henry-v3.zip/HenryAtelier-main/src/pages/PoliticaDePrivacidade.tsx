import React from "react";
import LegalPageLayout from "@/components/layout/LegalPageLayout";

export default function PoliticaDePrivacidade() {
  return (
    <LegalPageLayout title="Política de Privacidade" updatedAt="[preencher data de publicação]">
      <section>
        <p>
          Esta Política de Privacidade explica como a Maison Henry coleta, usa, armazena e protege os dados
          pessoais dos usuários e clientes do site, em conformidade com a Lei Geral de Proteção de Dados
          (LGPD — Lei nº 13.709/2018).
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">1. Quais dados coletamos</h2>
        <ul className="list-disc pl-5 space-y-1">
          <li>Dados de cadastro/checkout: nome, e-mail, telefone, endereço de entrega.</li>
          <li>Dados de pagamento: processados diretamente pelo Mercado Pago — não armazenamos número de
            cartão no nosso banco de dados.</li>
          <li>Dados de navegação: páginas visitadas e itens no carrinho, para funcionamento do site.</li>
          <li>Mensagens enviadas pelo formulário de contato ou WhatsApp.</li>
        </ul>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">2. Para que usamos seus dados</h2>
        <ul className="list-disc pl-5 space-y-1">
          <li>Processar e entregar seus pedidos.</li>
          <li>Enviar atualizações sobre o status da compra.</li>
          <li>Responder dúvidas enviadas por contato ou WhatsApp.</li>
          <li>Cumprir obrigações legais e fiscais.</li>
        </ul>
        <p className="mt-2">Não vendemos nem compartilhamos seus dados com terceiros para fins de marketing.</p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">3. Com quem compartilhamos</h2>
        <p>
          Compartilhamos apenas o estritamente necessário com: Mercado Pago (processamento de pagamento),
          transportadora/correios (entrega) e Supabase (infraestrutura de banco de dados que hospeda o site,
          com servidores fora do Brasil).
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">4. Armazenamento e segurança</h2>
        <p>
          Seus dados ficam armazenados em banco de dados protegido por controle de acesso. Mantemos seus
          dados pelo tempo necessário para cumprir finalidades legais, fiscais e de atendimento — em geral,
          pelo prazo do histórico de pedidos, salvo pedido de exclusão.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">5. Seus direitos</h2>
        <p>Como titular dos dados, você pode solicitar a qualquer momento:</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Confirmação de que tratamos seus dados e acesso a eles;</li>
          <li>Correção de dados incompletos ou desatualizados;</li>
          <li>Exclusão dos seus dados (exceto os que somos obrigados a manter por lei, como registros
            fiscais de pedidos já pagos);</li>
          <li>Revogação de consentimento.</li>
        </ul>
        <p className="mt-2">
          Para exercer esses direitos, entre em contato pelo e-mail{" "}
          <strong>[e-mail de contato]</strong>.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">6. Cookies</h2>
        <p>
          Usamos apenas cookies/armazenamento local essenciais ao funcionamento do site (ex.: manter os
          itens do seu carrinho). Não usamos cookies de rastreamento publicitário de terceiros.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">7. Contato do responsável</h2>
        <p>
          Dúvidas sobre esta política podem ser enviadas para <strong>[e-mail de contato]</strong>,
          responsável por: <strong>[Nome completo]</strong>.
        </p>
      </section>
    </LegalPageLayout>
  );
}
