import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Eye, EyeOff, Shield } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { ADMIN_EMAILS } from "@/constants";
import { toast } from "sonner";

interface AdminLoginProps {
  onSuccess: () => void;
}

export default function AdminLogin({ onSuccess }: AdminLoginProps) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      toast.error("Preencha todos os campos.");
      return;
    }
    setLoading(true);

    const { data, error } = await supabase.auth.signInWithPassword({
      email: form.email,
      password: form.password,
    });

    if (error) {
      toast.error(
        error.message.includes("Invalid login")
          ? "E-mail ou senha incorretos."
          : error.message
      );
      setLoading(false);
      return;
    }

    const email = (data.user?.email ?? "").toLowerCase();
    const isAdmin = ADMIN_EMAILS.includes(email);

    if (!isAdmin) {
      // É uma conta Supabase válida, mas sem permissão de admin —
      // não deixamos a sessão de "cliente" logada nesta tela.
      await supabase.auth.signOut();
      toast.error("Este e-mail não tem permissão de administrador.");
      setLoading(false);
      return;
    }

    onSuccess();
    toast.success("Bem-vindo ao painel administrativo!");
    navigate("/admin");
    // Não chamamos setLoading(false) — deixa a navegação acontecer.
  };

  return (
    <div className="min-h-screen bg-stone-950 flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 bg-stone-800 mb-5">
            <Shield size={24} className="text-gold" />
          </div>
          <h1 className="font-playfair text-2xl text-white mb-2">Acesso Administrativo</h1>
          <p className="text-stone-500 text-sm">Maison Henry — Painel de Controle</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="admin-email" className="block text-sm text-stone-400 mb-1.5">
              E-mail
            </label>
            <input
              id="admin-email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="admin@email.com"
              autoComplete="email"
              className="w-full bg-stone-900 border border-stone-700 px-4 py-3 text-white placeholder:text-stone-600 focus:outline-none focus:border-gold text-sm"
            />
          </div>

          <div>
            <label htmlFor="admin-password" className="block text-sm text-stone-400 mb-1.5">
              Senha
            </label>
            <div className="relative">
              <input
                id="admin-password"
                type={showPassword ? "text" : "password"}
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="Senha de acesso"
                autoComplete="current-password"
                className="w-full bg-stone-900 border border-stone-700 px-4 py-3 pr-11 text-white placeholder:text-stone-600 focus:outline-none focus:border-gold text-sm"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-gold text-white py-4 font-lato font-semibold tracking-widest uppercase text-sm hover:bg-gold-dark disabled:opacity-60 disabled:cursor-not-allowed transition-colors duration-200 mt-2"
          >
            <Shield size={16} />
            {loading ? "Autenticando..." : "Acessar Painel"}
          </button>
        </form>

        <div className="mt-8 text-center">
          <Link to="/" className="text-stone-600 text-xs hover:text-stone-400 transition-colors">
            ← Voltar à loja
          </Link>
        </div>
      </div>
    </div>
  );
}
