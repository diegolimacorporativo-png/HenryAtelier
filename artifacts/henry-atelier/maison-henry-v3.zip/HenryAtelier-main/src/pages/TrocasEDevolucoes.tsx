import React from "react";
import LegalPageLayout from "@/components/layout/LegalPageLayout";

export default function TrocasEDevolucoes() {
  return (
    <LegalPageLayout title="Trocas e Devoluções" updatedAt="[preencher data de publicação]">
      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">1. Direito de arrependimento (7 dias)</h2>
        <p>
          Como sua compra foi feita fora de um estabelecimento físico, o Código de Defesa do Consumidor
          (art. 49) garante o direito de se arrepender da compra em até <strong>7 (sete) dias corridos</strong>{" "}
          contados a partir do recebimento do produto, sem precisar justificar o motivo. Nesse caso, você
          tem direito à devolução integral do valor pago, incluindo o frete.
        </p>
        <p className="mt-2">
          Para exercer esse direito, entre em contato pelo WhatsApp ou e-mail informando o número do pedido.
          O produto deve ser devolvido sem sinais de uso, na embalagem original.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">2. Produto com defeito</h2>
        <p>
          Caso o produto chegue danificado ou com defeito de fabricação, você tem até{" "}
          <strong>90 dias</strong> (produto durável, conforme art. 26 do CDC) para solicitar troca,
          reparo ou devolução do valor pago. Recomendamos registrar fotos do produto e da embalagem assim
          que recebido.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">3. Como solicitar</h2>
        <ol className="list-decimal pl-5 space-y-1">
          <li>Entre em contato pelo WhatsApp ou pelo formulário de contato, informando o número do pedido.</li>
          <li>Nossa equipe vai orientar sobre o envio do produto de volta (o custo do frete de devolução é
            nosso, em caso de defeito ou arrependimento).</li>
          <li>Após recebermos e conferirmos o produto, o reembolso é feito pelo mesmo meio de pagamento
            utilizado na compra, em até [X] dias úteis.</li>
        </ol>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">4. O que não é coberto</h2>
        <p>
          Produtos usados/queimados (no caso das velas) fora do prazo de arrependimento, ou danificados por
          mau uso, não são elegíveis para troca — exceto quando o defeito for de fabricação.
        </p>
      </section>

      <section>
        <h2 className="font-playfair text-lg text-stone-900 mb-2">5. Dúvidas</h2>
        <p>
          Fale com a gente pelo WhatsApp ou pelo e-mail <strong>[e-mail de contato]</strong> — respondemos o
          mais rápido possível.
        </p>
      </section>
    </LegalPageLayout>
  );
}
