import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

interface LegalPageLayoutProps {
  title: string;
  updatedAt: string;
  children: React.ReactNode;
}

export default function LegalPageLayout({ title, updatedAt, children }: LegalPageLayoutProps) {
  return (
    <div className="min-h-screen bg-beige-light">
      <header className="bg-white border-b border-stone-200 px-6 py-5">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <Link to="/" className="font-playfair text-lg brand-gold">Maison Henry</Link>
          <Link to="/" className="flex items-center gap-1.5 text-xs text-stone-500 hover:text-gold transition-colors tracking-widest uppercase">
            <ArrowLeft size={14} /> Voltar à loja
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-14">
        <h1 className="font-playfair text-3xl text-stone-900 mb-2">{title}</h1>
        <p className="text-xs text-stone-400 mb-10">Última atualização: {updatedAt}</p>
        <div className="prose-legal text-sm text-stone-700 leading-relaxed space-y-6">
          {children}
        </div>
      </main>

      <footer className="border-t border-stone-200 py-8 text-center">
        <p className="text-xs text-stone-400">© {new Date().getFullYear()} Maison Henry. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
