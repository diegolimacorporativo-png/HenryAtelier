import React, { useRef, useState } from "react";
import { Upload, X, Image as ImageIcon, Video as VideoIcon, Link2 } from "lucide-react";
import { supabase } from "@/lib/supabase";

interface HeroMediaUploaderProps {
  url: string;
  type: "image" | "video";
  onChange: (url: string, type: "image" | "video") => void;
}

const BUCKET = "site-media";
const MAX_IMAGE_MB = 10;
const MAX_VIDEO_MB = 60;

export default function HeroMediaUploader({ url, type, onChange }: HeroMediaUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [urlInput, setUrlInput] = useState(url || "");
  const [mode, setMode] = useState<"file" | "url">("file");
  const fileRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File) => {
    const isVideo = file.type.startsWith("video/");
    const isImage = file.type.startsWith("image/");
    if (!isVideo && !isImage) {
      alert("Selecione uma imagem (JPG, PNG, WebP) ou um vídeo (MP4, WebM).");
      return;
    }
    const maxBytes = (isVideo ? MAX_VIDEO_MB : MAX_IMAGE_MB) * 1024 * 1024;
    if (file.size > maxBytes) {
      alert(`Arquivo muito grande. Máximo: ${isVideo ? MAX_VIDEO_MB : MAX_IMAGE_MB} MB.`);
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || (isVideo ? "mp4" : "jpg");
      const path = `hero/${crypto.randomUUID()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from(BUCKET)
        .upload(path, file, { cacheControl: "3600", upsert: false });
      if (uploadError) throw uploadError;
      const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
      onChange(data.publicUrl, isVideo ? "video" : "image");
      setUrlInput(data.publicUrl);
    } catch (err) {
      console.error("Hero media upload error:", err);
      alert("Erro ao enviar o arquivo. Verifique se o bucket 'site-media' existe no Supabase Storage (veja o schema SQL).");
    } finally {
      setUploading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
    e.target.value = "";
  };

  const handleUrlApply = () => {
    if (!urlInput.trim()) return;
    const guessedType: "image" | "video" = /\.(mp4|webm|mov|m4v)(\?.*)?$/i.test(urlInput) ? "video" : "image";
    onChange(urlInput.trim(), guessedType);
  };

  return (
    <div>
      <div className="flex gap-2 mb-3">
        <button type="button" onClick={() => setMode("file")} className={`px-3 py-1.5 text-xs font-medium tracking-wide uppercase ${mode === "file" ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-500"}`}>
          <Upload size={12} className="inline mr-1" /> Enviar arquivo
        </button>
        <button type="button" onClick={() => setMode("url")} className={`px-3 py-1.5 text-xs font-medium tracking-wide uppercase ${mode === "url" ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-500"}`}>
          <Link2 size={12} className="inline mr-1" /> Usar URL
        </button>
      </div>

      {mode === "file" ? (
        <div
          onClick={() => fileRef.current?.click()}
          className="border-2 border-dashed border-stone-300 hover:border-gold p-6 text-center cursor-pointer transition-colors"
        >
          <input ref={fileRef} type="file" accept="image/*,video/*" onChange={handleFileChange} className="hidden" />
          {uploading ? (
            <div className="flex flex-col items-center gap-2">
              <div className="w-5 h-5 border-2 border-gold border-t-transparent rounded-full animate-spin" />
              <p className="text-xs text-stone-500">Enviando...</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-1.5 text-stone-400">
              <div className="flex gap-2"><ImageIcon size={18} /><VideoIcon size={18} /></div>
              <p className="text-xs">Clique para escolher uma imagem ou vídeo</p>
              <p className="text-[10px] text-stone-300">JPG/PNG/WebP até {MAX_IMAGE_MB}MB · MP4/WebM até {MAX_VIDEO_MB}MB</p>
            </div>
          )}
        </div>
      ) : (
        <div className="flex gap-2">
          <input
            type="url"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="https://exemplo.com/video.mp4 ou imagem.jpg"
            className="flex-1 border border-stone-200 px-3 py-2.5 text-sm focus:outline-none focus:border-gold"
          />
          <button type="button" onClick={handleUrlApply} className="px-4 bg-stone-900 text-white text-xs uppercase tracking-wide">Usar</button>
        </div>
      )}

      {url && (
        <div className="mt-4 relative border border-stone-200">
          {type === "video" ? (
            <video src={url} className="w-full h-40 object-cover" muted autoPlay loop playsInline />
          ) : (
            <img src={url} alt="Prévia do fundo do cabeçalho" className="w-full h-40 object-cover" />
          )}
          <button
            type="button"
            onClick={() => { onChange("", "image"); setUrlInput(""); }}
            className="absolute top-2 right-2 bg-stone-900/80 text-white p-1.5 hover:bg-red-600 transition-colors"
            title="Remover e usar o fundo padrão"
          >
            <X size={14} />
          </button>
          <span className="absolute bottom-2 left-2 bg-stone-900/80 text-white text-[10px] uppercase tracking-wide px-2 py-1">
            {type === "video" ? "Vídeo" : "Imagem"}
          </span>
        </div>
      )}
    </div>
  );
}
