import type { Product, Order, ContactMessage, AppSettings } from "@/types";

// E-mails com acesso ao painel /admin. A senha NUNCA fica aqui —
// cada admin faz login com sua própria conta Supabase Auth
// (criada em Authentication → Users no painel do Supabase).
// Troque pelo(s) e-mail(s) reais da equipe antes de publicar.
export const ADMIN_EMAILS = ["admin@maisonhenry.com.br"];

// Legacy localStorage products (fallback only)
export const INITIAL_PRODUCTS: Product[] = [];
export const INITIAL_ORDERS: Order[] = [];
export const INITIAL_CONTACTS: ContactMessage[] = [];

export const DEFAULT_SETTINGS: AppSettings = {
  whatsapp_phone: "5511999999999",
  contact_email: "contato@maisonhenry.com.br",
  contact_phone: "(11) 99999-9999",
  instagram_url: "https://instagram.com/maisonhenry",
  // Legacy
  whatsappPhone: "5511999999999",
  contactEmail: "contato@maisonhenry.com.br",
  contactPhone: "(11) 99999-9999",
};

export const AROMAS = [
  { name: "Baunilha", icon: "🍦" },
  { name: "Lavanda Suave", icon: "💜" },
  { name: "Canela & Maçã", icon: "🍎" },
  { name: "Capim Limão", icon: "🌿" },
  { name: "Coco & Açúcar", icon: "🥥" },
  { name: "Algodão", icon: "☁️" },
  { name: "Flor de Cerejeira", icon: "🌸" },
];

export const CATEGORY_LABELS: Record<string, string> = {
  atelier: "Linha Atelier",
  aromas: "Aromas",
  "henry-home": "Henry Home",
  "don-henry": "Don Henry",
};

export const ORDER_STATUS_LABELS: Record<string, string> = {
  pending: "Pendente",
  registered: "Registrado",
  paid: "Pago",
  processing: "Processando",
  shipped: "Enviado",
  in_transit: "Em Trânsito",
  delivered: "Entregue",
  canceled: "Cancelado",
  refunded: "Reembolsado",
};
