import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

// ── O cliente só manda ISSO. Preço, estoque, cupom e frete
// são sempre calculados aqui a partir do banco — nunca confiamos
// em valores vindos do navegador. ─────────────────────────────
interface PaymentRequestBody {
  order: {
    customer_name: string;
    customer_email: string;
    customer_phone?: string;
    customer_address?: string;
    customer_city?: string;
    customer_state?: string;
    customer_zip?: string;
    user_id?: string;
    items: Array<{ product_id: string; quantity: number }>;
    coupon_code?: string;
  };
}

const DEFAULT_SHIPPING = 15.9;

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const ACCESS_TOKEN = Deno.env.get("MERCADO_PAGO_ACCESS_TOKEN");
    if (!ACCESS_TOKEN) {
      console.error("[create-payment] MERCADO_PAGO_ACCESS_TOKEN not set");
      return new Response(
        JSON.stringify({ error: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (ACCESS_TOKEN.startsWith("TEST-") || ACCESS_TOKEN.startsWith("test-")) {
      console.error("[create-payment] CRITICAL: TEST token detected — PRODUCTION token (APP_USR) required. Blocking execution.");
      return new Response(
        JSON.stringify({ error: "Configuração inválida: token de teste detectado. Use credencial de produção APP_USR." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!ACCESS_TOKEN.startsWith("APP_USR-")) {
      console.error("[create-payment] CRITICAL: Unrecognized token format. Expected APP_USR-. Blocking execution.");
      return new Response(
        JSON.stringify({ error: "Token de produção inválido. Formato esperado: APP_USR-" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("[create-payment] Production token validated (APP_USR).");

    const body: PaymentRequestBody = await req.json();
    const { order } = body;

    if (!order || !order.items || order.items.length === 0) {
      return new Response(
        JSON.stringify({ error: "Invalid order data" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    if (!order.customer_name || !order.customer_email) {
      return new Response(
        JSON.stringify({ error: "Nome e e-mail são obrigatórios." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // ── STEP 1: Buscar produtos reais no banco (nunca confiar no cliente) ──
    const productIds = order.items.map((i) => i.product_id);
    const { data: dbProducts, error: productsError } = await supabaseAdmin
      .from("products")
      .select("id, name, price, image_url, stock, active")
      .in("id", productIds);

    if (productsError || !dbProducts) {
      console.error("[create-payment] Failed to fetch products:", productsError);
      return new Response(
        JSON.stringify({ error: "Erro ao validar produtos." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const productMap = new Map(dbProducts.map((p) => [p.id, p]));

    // ── STEP 2: Validar disponibilidade + montar itens com preço do banco ──
    const outOfStock: string[] = [];
    const lineItems: Array<{ product_id: string; name: string; price: number; image_url: string | null; quantity: number }> = [];

    for (const reqItem of order.items) {
      const qty = Math.max(1, Math.floor(Number(reqItem.quantity) || 0));
      const product = productMap.get(reqItem.product_id);
      if (!product || !product.active) {
        outOfStock.push(reqItem.product_id);
        continue;
      }
      if ((product.stock ?? 0) < qty) {
        outOfStock.push(product.name);
        continue;
      }
      lineItems.push({
        product_id: product.id,
        name: product.name,
        price: Number(product.price),
        image_url: product.image_url,
        quantity: qty,
      });
    }

    if (outOfStock.length > 0) {
      return new Response(
        JSON.stringify({ error: `Sem estoque suficiente para: ${outOfStock.join(", ")}` }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const subtotal = lineItems.reduce((sum, li) => sum + li.price * li.quantity, 0);

    // ── STEP 3: Validar cupom no servidor (nunca confiar no valor de desconto do cliente) ──
    let discount = 0;
    let couponCode: string | null = null;
    if (order.coupon_code) {
      const { data: coupon } = await supabaseAdmin
        .from("coupons")
        .select("*")
        .eq("code", order.coupon_code.toUpperCase())
        .eq("active", true)
        .single();

      const validCoupon =
        coupon &&
        (!coupon.min_order || subtotal >= coupon.min_order) &&
        (!coupon.expires_at || new Date(coupon.expires_at) >= new Date()) &&
        (!coupon.max_uses || coupon.uses_count < coupon.max_uses);

      if (validCoupon) {
        discount = coupon.type === "percent" ? subtotal * (coupon.value / 100) : Math.min(coupon.value, subtotal);
        couponCode = coupon.code;
      }
    }

    // ── STEP 4: Frete a partir das configurações do banco ──
    const { data: settingsRows } = await supabaseAdmin
      .from("settings")
      .select("key, value")
      .eq("key", "free_shipping_above");
    const freeShippingAbove = Number(settingsRows?.[0]?.value ?? 199);

    const afterDiscount = subtotal - discount;
    const shipping = afterDiscount >= freeShippingAbove ? 0 : DEFAULT_SHIPPING;
    const total = Number((afterDiscount + shipping).toFixed(2));

    console.log("[create-payment] Server-computed total:", total, "for:", order.customer_email);

    // ── STEP 5: Salvar pedido com os valores calculados no servidor ──
    const { data: savedOrder, error: orderError } = await supabaseAdmin
      .from("orders")
      .insert([{
        customer_name: order.customer_name,
        customer_email: order.customer_email,
        customer_phone: order.customer_phone ?? null,
        customer_address: order.customer_address ?? null,
        customer_city: order.customer_city ?? null,
        customer_state: order.customer_state ?? null,
        customer_zip: order.customer_zip ?? null,
        user_id: order.user_id ?? null,
        items: lineItems.map((li) => ({
          product: { id: li.product_id, name: li.name, price: li.price, image_url: li.image_url },
          quantity: li.quantity,
        })),
        subtotal,
        shipping,
        discount,
        total,
        payment_method: "mercado_pago",
        coupon_code: couponCode,
        status: "pending",
        payment_status: "pending",
      }])
      .select()
      .single();

    if (orderError) {
      console.error("[create-payment] DB insert error:", orderError);
      return new Response(
        JSON.stringify({ error: "Failed to create order: " + orderError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("[create-payment] Order saved:", savedOrder.order_number, "ID:", savedOrder.id);

    // ── Build Mercado Pago preference (a partir dos valores do servidor) ──
    const baseUrl = req.headers.get("origin") ?? "https://henryatelier.onspace.app";
    const webhookUrl = `${Deno.env.get("SUPABASE_URL")}/functions/v1/webhook-mercadopago`;

    const mpItems = lineItems.map((li) => ({
      id: li.product_id,
      title: li.name,
      quantity: li.quantity,
      unit_price: Number(li.price.toFixed(2)),
      currency_id: "BRL",
      picture_url: li.image_url ?? undefined,
    }));

    if (shipping > 0) {
      mpItems.push({ id: "shipping", title: "Frete", quantity: 1, unit_price: Number(shipping.toFixed(2)), currency_id: "BRL", picture_url: undefined });
    }
    if (discount > 0) {
      mpItems.push({ id: "discount", title: "Desconto", quantity: 1, unit_price: Number((-discount).toFixed(2)), currency_id: "BRL", picture_url: undefined });
    }

    const preferenceBody = {
      items: mpItems,
      payer: {
        name: order.customer_name,
        email: order.customer_email,
        phone: order.customer_phone
          ? { area_code: order.customer_phone.replace(/\D/g, "").slice(0, 2), number: order.customer_phone.replace(/\D/g, "").slice(2) }
          : undefined,
        address: order.customer_address
          ? { zip_code: order.customer_zip?.replace(/\D/g, "") ?? "", street_name: order.customer_address }
          : undefined,
      },
      external_reference: savedOrder.id,
      statement_descriptor: "Henry Atelier",
      back_urls: {
        success: `${baseUrl}/checkout/sucesso?order=${savedOrder.order_number}`,
        failure: `${baseUrl}/checkout?payment=failed`,
        pending: `${baseUrl}/checkout/pendente?order=${savedOrder.order_number}`,
      },
      auto_return: "approved",
      notification_url: webhookUrl,
      metadata: { order_id: savedOrder.id, order_number: savedOrder.order_number },
    };

    console.log("[create-payment] Calling Mercado Pago API...");

    const mpResponse = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${ACCESS_TOKEN}`,
        "Content-Type": "application/json",
        "X-Idempotency-Key": savedOrder.id,
      },
      body: JSON.stringify(preferenceBody),
    });

    const mpData = await mpResponse.json();

    if (!mpResponse.ok) {
      console.error("[create-payment] Mercado Pago error:", JSON.stringify(mpData));
      await supabaseAdmin.from("orders").update({ status: "canceled", notes: `MP Error: ${JSON.stringify(mpData)}` }).eq("id", savedOrder.id);
      return new Response(
        JSON.stringify({ error: "Mercado Pago: " + (mpData.message ?? mpData.cause?.[0]?.description ?? "Unknown error") }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("[create-payment] Preference created:", mpData.id);

    const initPoint: string = mpData.init_point ?? "";
    if (!initPoint || initPoint.includes("sandbox") || initPoint.includes("beta")) {
      console.error("[create-payment] CRITICAL: sandbox or invalid init_point detected:", initPoint, "— Blocking redirect.");
      await supabaseAdmin.from("orders").update({ status: "canceled", notes: "Sandbox URL detected — blocked by production guard." }).eq("id", savedOrder.id);
      return new Response(
        JSON.stringify({ error: "URL de sandbox detectada. Verifique a credencial de produção APP_USR no painel." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("[create-payment] Production init_point validated:", initPoint.slice(0, 60) + "...");

    await supabaseAdmin.from("orders").update({ stripe_payment_intent_id: mpData.id }).eq("id", savedOrder.id);

    await supabaseAdmin.from("email_logs").insert([{
      order_id: savedOrder.id,
      type: "payment_created",
      recipient: order.customer_email,
      subject: `Pagamento criado — ${savedOrder.order_number}`,
      status: "sent",
      sent_at: new Date().toISOString(),
    }]);

    return new Response(
      JSON.stringify({
        success: true,
        order_id: savedOrder.id,
        order_number: savedOrder.order_number,
        preference_id: mpData.id,
        init_point: initPoint,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err) {
    console.error("[create-payment] Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error: " + String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
