import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

// Mercado Pago payment status → order status mapping
const MP_STATUS_MAP: Record<string, { status: string; payment_status: string }> = {
  approved: { status: "paid", payment_status: "paid" },
  pending: { status: "pending", payment_status: "pending" },
  in_process: { status: "pending", payment_status: "pending" },
  rejected: { status: "canceled", payment_status: "rejected" },
  cancelled: { status: "canceled", payment_status: "cancelled" },
  refunded: { status: "refunded", payment_status: "refunded" },
  charged_back: { status: "refunded", payment_status: "charged_back" },
};

serve(async (req: Request) => {
  // ── CORS Preflight ─────────────────────────────
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // Only accept POST
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  try {
    const ACCESS_TOKEN = Deno.env.get("MERCADO_PAGO_ACCESS_TOKEN");
    if (!ACCESS_TOKEN) {
      console.error("[webhook-mp] MERCADO_PAGO_ACCESS_TOKEN not set");
      return new Response("Gateway not configured", { status: 500, headers: corsHeaders });
    }

    // ── Init Supabase admin client ─────────────────
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // ── Parse webhook body ─────────────────────────
    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      console.error("[webhook-mp] Failed to parse body");
      return new Response("Invalid JSON", { status: 400, headers: corsHeaders });
    }

    console.log("[webhook-mp] Received:", JSON.stringify(body));

    const topic = body.type as string;
    const dataId = (body.data as Record<string, string>)?.id;

    // ── Only process payment notifications ─────────
    if (topic !== "payment" || !dataId) {
      console.log("[webhook-mp] Skipping non-payment topic:", topic, "id:", dataId);
      return new Response("ok", { status: 200, headers: corsHeaders });
    }

    const paymentId = String(dataId);
    console.log("[webhook-mp] Processing payment ID:", paymentId);

    // ── STEP 1: Query Mercado Pago API for real status ──
    // NEVER trust the webhook body alone — always validate with the API
    const mpResponse = await fetch(
      `https://api.mercadopago.com/v1/payments/${paymentId}`,
      {
        headers: {
          "Authorization": `Bearer ${ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (!mpResponse.ok) {
      const errText = await mpResponse.text();
      console.error("[webhook-mp] MP API error:", mpResponse.status, errText);
      return new Response("MP API error", { status: 502, headers: corsHeaders });
    }

    const payment = await mpResponse.json();
    const mpStatus = payment.status as string;
    const externalRef = payment.external_reference as string; // order_id from DB
    const mpAmount = payment.transaction_amount as number;

    console.log("[webhook-mp] Payment status:", mpStatus, "| Order ID:", externalRef, "| Amount:", mpAmount);

    if (!externalRef) {
      console.error("[webhook-mp] No external_reference in payment:", paymentId);
      return new Response("ok", { status: 200, headers: corsHeaders });
    }

    // ── STEP 2: Fetch order from DB ────────────────
    const { data: order, error: fetchError } = await supabaseAdmin
      .from("orders")
      .select("id, order_number, status, payment_status, total, customer_email, customer_name")
      .eq("id", externalRef)
      .single();

    if (fetchError || !order) {
      console.error("[webhook-mp] Order not found:", externalRef, fetchError);
      return new Response("ok", { status: 200, headers: corsHeaders });
    }

    console.log("[webhook-mp] Found order:", order.order_number, "Current status:", order.status);

    // ── STEP 3: Only update if status changed ─────
    const statusMap = MP_STATUS_MAP[mpStatus] ?? { status: "pending", payment_status: mpStatus };

    // Prevent downgrading from paid/delivered status
    if (order.status === "paid" || order.status === "delivered" || order.status === "shipped") {
      console.log("[webhook-mp] Order already in final state, skipping update:", order.status);
      return new Response("ok", { status: 200, headers: corsHeaders });
    }

    // ── STEP 4: Update order status in DB ─────────
    const updatePayload: Record<string, unknown> = {
      payment_status: statusMap.payment_status,
      updated_at: new Date().toISOString(),
    };

    // Only update main status if payment is approved
    if (mpStatus === "approved") {
      updatePayload.status = "paid";
      updatePayload.notes = `Pagamento aprovado via Mercado Pago. Payment ID: ${paymentId}`;
      console.log("[webhook-mp] ✅ PAYMENT APPROVED — updating order to PAID:", order.order_number);
    } else if (mpStatus === "rejected" || mpStatus === "cancelled") {
      updatePayload.status = "canceled";
      updatePayload.notes = `Pagamento ${mpStatus} via Mercado Pago. Payment ID: ${paymentId}`;
      console.log("[webhook-mp] ❌ Payment rejected/cancelled:", order.order_number);
    } else {
      console.log("[webhook-mp] Payment in intermediate state:", mpStatus, "for order:", order.order_number);
    }

    const { error: updateError } = await supabaseAdmin
      .from("orders")
      .update(updatePayload)
      .eq("id", order.id);

    if (updateError) {
      console.error("[webhook-mp] DB update error:", updateError);
      return new Response("DB error", { status: 500, headers: corsHeaders });
    }

    // ── STEP 4.5: Baixar estoque só quando o pagamento é aprovado ──
    // (Nunca no momento da criação — se descontássemos ao criar a
    // preferência, um carrinho abandonado prenderia estoque de graça.)
    if (mpStatus === "approved") {
      const { data: fullOrder } = await supabaseAdmin
        .from("orders")
        .select("items")
        .eq("id", order.id)
        .single();

      const items = (fullOrder?.items ?? []) as Array<{ product: { id: string }; quantity: number }>;
      for (const item of items) {
        const productId = item.product?.id;
        const qty = Number(item.quantity) || 0;
        if (!productId || qty <= 0) continue;
        const { error: stockError } = await supabaseAdmin.rpc("decrement_stock", {
          p_product_id: productId,
          p_quantity: qty,
        });
        if (stockError) {
          console.error("[webhook-mp] Failed to decrement stock for", productId, stockError);
        }
      }
      console.log("[webhook-mp] Stock decremented for", items.length, "item(s) —", order.order_number);
    }

    // ── STEP 5: Log webhook event ──────────────────
    await supabaseAdmin.from("email_logs").insert([{
      order_id: order.id,
      type: `mp_webhook_${mpStatus}`,
      recipient: order.customer_email,
      subject: `Webhook MP: ${mpStatus} — ${order.order_number}`,
      status: "sent",
      sent_at: new Date().toISOString(),
    }]);

    console.log("[webhook-mp] ✓ Webhook processed. Order:", order.order_number, "→", updatePayload.status ?? order.status);

    return new Response(
      JSON.stringify({ received: true, order_number: order.order_number, status: mpStatus }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err) {
    console.error("[webhook-mp] Unexpected error:", err);
    // Always return 200 to prevent Mercado Pago retry flood
    return new Response("ok", { status: 200, headers: corsHeaders });
  }
});
